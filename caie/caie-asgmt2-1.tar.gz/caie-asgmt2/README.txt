To use the program compile with gcc CSC139-2 -lpthread -lrt
After compilations type a.out A B C 
A = Time for sleep before terminating
B = Number of producer threads
C = number of consumers threads
