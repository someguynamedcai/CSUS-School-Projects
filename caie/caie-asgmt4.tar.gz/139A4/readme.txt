Use g++ A4.cpp to compile the program
After compilation, use a.out <text file> <algorithm>
For example: a.out input.txt FIFO
The text file must be in the format stated: The first 3 numbers will be the pages, number of frames, and total page requests respectively.
Afterwards the pages can be placed.