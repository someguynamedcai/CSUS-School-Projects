Use g++ CSC139A2.c
After compilation is done use a.out <file name> <Scheduling Algorithm>
For Round Robin you must also add another argument indicating the time quantum.

EXAMPLE: a.out input.txt RR 2 (2 = time quantum)