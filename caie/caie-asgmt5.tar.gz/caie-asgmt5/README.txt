Use g++ to compile all individual files. 
After compilation, use a.out following the list of tracks that will be used.
For example: a.out 1 100 50 38 20